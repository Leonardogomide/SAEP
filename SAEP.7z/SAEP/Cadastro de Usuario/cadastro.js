// Função para validar o e-mail
function validaEmail(email) {
    const re = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
    return re.test(email);
  }
  
  // Função de envio de formulário (Cadastro de Usuário)
  document.getElementById("cadastroUsuario").addEventListener("submit", function(e) {
    e.preventDefault();
    const nome = document.getElementById("nome").value;
    const email = document.getElementById("email").value;
  
    if (!nome || !email) {
      showMessage("Por favor, preencha todos os campos.", "error");
      return;
    }
  
    if (!validaEmail(email)) {
      showMessage("Por favor, insira um e-mail válido.", "error");
      return;
    }
  
    // Simula o envio do formulário e mostra a mensagem de sucesso
    showMessage("Cadastro concluído com sucesso!", "success");
    // Aqui, você poderia realizar a persistência no banco de dados (via AJAX, por exemplo)
  });
  
  // Função para exibir mensagens de sucesso ou erro
  function showMessage(message, type) {
    const messageBox = document.createElement("div");
    messageBox.classList.add(type === "success" ? "success-message" : "error-message");
    messageBox.innerText = message;
    document.body.appendChild(messageBox);
    
    setTimeout(() => {
      messageBox.remove();
    }, 3000); // Remove a mensagem após 3 segundos
  }
  
  // Função para manipular o cadastro de Tarefas
  document.getElementById("cadastroTarefa").addEventListener("submit", function(e) {
    e.preventDefault();
    const descricao = document.getElementById("descricao").value;
    const setor = document.getElementById("setor").value;
    const prioridade = document.getElementById("prioridade").value;
    const usuario = document.getElementById("usuario").value;
  
    if (!descricao || !setor || !prioridade || !usuario) {
      showMessage("Todos os campos são obrigatórios.", "error");
      return;
    }
  
    // Simula o envio da tarefa
    showMessage("Tarefa cadastrada com sucesso!", "success");
    // Aqui, você também poderia salvar a tarefa no banco de dados.
  });
  
  // Função para alterar o status de uma tarefa
  function alterarStatus(tarefaId) {
    const status = document.getElementById("status-" + tarefaId).value;
    
    // Aqui você pode realizar a atualização do status da tarefa no banco de dados
    showMessage(`Status da tarefa ${tarefaId} alterado para "${status}"`, "success");
    
    // Atualiza a visualização da tarefa
    atualizarTelaTarefa(tarefaId, status);
  }
  
  // Função para atualizar a tela com as informações da tarefa
  function atualizarTelaTarefa(tarefaId, novoStatus) {
    const tarefa = document.getElementById("tarefa-" + tarefaId);
    const statusColuna = document.getElementById(novoStatus); // Coluna 'a fazer', 'fazendo', 'pronto'
  
    // Move a tarefa para a nova coluna de status
    statusColuna.appendChild(tarefa);
  }
  
  // Função para editar uma tarefa
  function editarTarefa(tarefaId) {
    alert("Redirecionando para a tela de edição da tarefa " + tarefaId);
    // Aqui, você poderia redirecionar para uma página de edição, por exemplo
  }
  
  // Função para excluir uma tarefa
  function excluirTarefa(tarefaId) {
    const confirmar = confirm("Você tem certeza que deseja excluir essa tarefa?");
    if (confirmar) {
      const tarefa = document.getElementById("tarefa-" + tarefaId);
      tarefa.remove();
      showMessage("Tarefa excluída com sucesso.", "success");
    }
  }
  